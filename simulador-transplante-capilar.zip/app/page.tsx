import SimuladorTransplanteCapilar from "@/components/simulador-transplante-capilar"

export default function Home() {
  return (
    <main>
      <SimuladorTransplanteCapilar />
    </main>
  )
}

