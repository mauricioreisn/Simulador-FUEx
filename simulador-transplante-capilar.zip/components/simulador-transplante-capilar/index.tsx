import { SimuladorTransplanteCapilar } from "./simulador"

export default SimuladorTransplanteCapilar

