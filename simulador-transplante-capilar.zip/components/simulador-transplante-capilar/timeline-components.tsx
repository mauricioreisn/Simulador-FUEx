"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"

export const Timeline = ({
  viewportStart,
  viewportEnd,
  resultados,
  handleViewportChange,
  formatarDuracao,
  horarioParaMinutos,
  adicionarMinutos,
}) => {
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState(null)
  const [isPanning, setIsPanning] = useState(false)
  const [panStart, setPanStart] = useState(null)
  const timelineRef = useRef(null)

  // Function to handle minimap dragging
  const handleMinimapMouseDown = (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const totalWidth = rect.width
    const hour = 8 + (14 * x) / totalWidth
    setIsDragging(true)
    setDragStart(hour)
  }

  const handleMinimapMouseMove = (e) => {
    if (!isDragging || !dragStart) return

    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const totalWidth = rect.width
    const currentHour = 8 + (14 * x) / totalWidth
    const diff = currentHour - dragStart

    handleViewportChange(viewportStart + diff, viewportEnd + diff)
  }

  const handleMinimapMouseUp = () => {
    setIsDragging(false)
    setDragStart(null)
  }

  // Handle mouse wheel zoom
  const handleWheel = (e) => {
    if (!resultados || !timelineRef.current) return

    e.preventDefault()

    // Get mouse position relative to the timeline
    const rect = timelineRef.current.getBoundingClientRect()
    const mouseX = e.clientX - rect.left
    const mousePercentage = mouseX / rect.width

    // Calculate the hour at mouse position
    const viewportWidth = viewportEnd - viewportStart
    const mouseHour = viewportStart + viewportWidth * mousePercentage

    // Determine zoom direction and factor
    const zoomFactor = e.deltaY > 0 ? 1.1 : 0.9 // Zoom out or in

    // Calculate new viewport width
    const newViewportWidth = Math.max(2, Math.min(14, viewportWidth * zoomFactor))

    // Calculate new viewport start and end, keeping mouse position at the same relative position
    let newStart = mouseHour - mousePercentage * newViewportWidth
    let newEnd = newStart + newViewportWidth

    // Adjust if out of bounds
    if (newStart < 8) {
      newStart = 8
      newEnd = newStart + newViewportWidth
    }
    if (newEnd > 22) {
      newEnd = 22
      newStart = Math.max(8, newEnd - newViewportWidth)
    }

    handleViewportChange(newStart, newEnd)
  }

  // Handle mouse panning
  const handleTimelineMouseDown = (e) => {
    if (!resultados || e.button !== 0) return // Only left mouse button

    setIsPanning(true)
    setPanStart({
      x: e.clientX,
      viewportStart,
      viewportEnd,
    })

    // Change cursor
    if (timelineRef.current) {
      timelineRef.current.style.cursor = "grabbing"
    }
  }

  const handleTimelineMouseMove = (e) => {
    if (!isPanning || !panStart || !timelineRef.current) return

    const rect = timelineRef.current.getBoundingClientRect()
    const deltaX = e.clientX - panStart.x
    const hourDelta = -(deltaX / rect.width) * (viewportEnd - viewportStart)

    const newStart = Math.max(8, Math.min(20, panStart.viewportStart + hourDelta))
    const newEnd = Math.min(22, Math.max(10, panStart.viewportEnd + hourDelta))

    // Only update if we can maintain the viewport width
    if (newEnd - newStart >= 2) {
      handleViewportChange(newStart, newEnd)
    }
  }

  const handleTimelineMouseUp = () => {
    setIsPanning(false)
    setPanStart(null)

    // Reset cursor
    if (timelineRef.current) {
      timelineRef.current.style.cursor = "default"
    }
  }

  // Add event listeners
  useEffect(() => {
    const currentRef = timelineRef.current
    if (currentRef) {
      currentRef.addEventListener("wheel", handleWheel, { passive: false })
    }

    // Cleanup
    return () => {
      if (currentRef) {
        currentRef.removeEventListener("wheel", handleWheel)
      }

      // Also clean up panning if component unmounts while panning
      document.removeEventListener("mousemove", handleTimelineMouseMove)
      document.removeEventListener("mouseup", handleTimelineMouseUp)
    }
  }, [viewportStart, viewportEnd, resultados])

  // Handle document-level mouse events for panning
  useEffect(() => {
    if (isPanning) {
      document.addEventListener("mousemove", handleTimelineMouseMove)
      document.addEventListener("mouseup", handleTimelineMouseUp)
    } else {
      document.removeEventListener("mousemove", handleTimelineMouseMove)
      document.removeEventListener("mouseup", handleTimelineMouseUp)
    }

    return () => {
      document.removeEventListener("mousemove", handleTimelineMouseMove)
      document.removeEventListener("mouseup", handleTimelineMouseUp)
    }
  }, [isPanning])

  if (!resultados) return null

  return (
    <div
      className="relative mt-10 mb-14"
      ref={timelineRef}
      onMouseDown={handleTimelineMouseDown}
      style={{ cursor: isPanning ? "grabbing" : "default" }}
    >
      {/* Timeline ruler with viewport control */}
      <div className="relative">
        {/* Main timeline */}
        <div className="flex items-center justify-between w-full mb-2 overflow-hidden">
          {Array.from({ length: (viewportEnd - viewportStart) * 4 }, (_, i) => {
            const hour = Math.floor(viewportStart + i / 4)
            const minute = (i % 4) * 15
            const isHour = minute === 0
            return (
              <div key={i} className="flex flex-col items-center">
                {isHour && <div className="text-xs text-gray-500">{`${hour.toString().padStart(2, "0")}:00`}</div>}
                <div className={`h-${isHour ? "2" : "1"} w-0.5 bg-gray-300 mt-1`}></div>
              </div>
            )
          })}
        </div>

        {/* Minimap timeline */}
        <div
          className="relative h-8 mt-4 bg-gray-100 rounded cursor-pointer"
          onMouseDown={handleMinimapMouseDown}
          onMouseMove={handleMinimapMouseMove}
          onMouseUp={handleMinimapMouseUp}
          onMouseLeave={handleMinimapMouseUp}
          title="Arraste para navegar ou use a roda do mouse para zoom"
        >
          {/* Full timeline representation */}
          <div className="absolute inset-0 flex">
            {resultados.etapas.map((etapa, index) => {
              const startPercent = ((horarioParaMinutos(etapa.inicio) - 8 * 60) / (14 * 60)) * 100
              const widthPercent = (etapa.duracao / (14 * 60)) * 100

              return (
                <div
                  key={index}
                  className="absolute h-full opacity-50"
                  style={{
                    left: `${startPercent}%`,
                    width: `${widthPercent}%`,
                    backgroundColor:
                      etapa.fase === "critica"
                        ? etapa.destaque
                          ? "rgb(239 68 68)"
                          : "rgb(251 191 36)"
                        : etapa.fase === "pre"
                          ? "rgb(96 165 250)"
                          : "rgb(74 222 128)",
                  }}
                />
              )
            })}
          </div>

          {/* Viewport indicator */}
          <div
            className="absolute h-full border-2 border-blue-500 bg-blue-100/20"
            style={{
              left: `${((viewportStart - 8) / 14) * 100}%`,
              width: `${((viewportEnd - viewportStart) / 14) * 100}%`,
            }}
          >
            {/* Drag handles */}
            <div className="absolute inset-y-0 left-0 w-1 bg-blue-500 cursor-ew-resize" />
            <div className="absolute inset-y-0 right-0 w-1 bg-blue-500 cursor-ew-resize" />
          </div>
        </div>

        {/* Zoom controls */}
        <div className="absolute right-0 top-0 flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const currentWidth = viewportEnd - viewportStart
              const newWidth = Math.max(2, currentWidth * 0.7)
              const center = (viewportStart + viewportEnd) / 2
              handleViewportChange(center - newWidth / 2, center + newWidth / 2)
            }}
          >
            +
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const currentWidth = viewportEnd - viewportStart
              const newWidth = Math.min(14, currentWidth * 1.3)
              const center = (viewportStart + viewportEnd) / 2
              handleViewportChange(center - newWidth / 2, center + newWidth / 2)
            }}
          >
            -
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              handleViewportChange(8, 22)
            }}
          >
            Reset
          </Button>
        </div>
      </div>

      {/* Timeline tracks */}
      <div className="relative">
        {/* Fase de preparação - track 1 */}
        <div className="mb-10 relative">
          <div className="absolute -top-6 left-0 text-sm font-medium text-blue-600 dark:text-blue-400">Preparação</div>
          {resultados.etapas
            .filter((etapa) => etapa.fase === "pre")
            .map((etapa, index) => {
              const startPercent =
                ((horarioParaMinutos(etapa.inicio) - viewportStart * 60) / ((viewportEnd - viewportStart) * 60)) * 100
              const widthPercent = (etapa.duracao / ((viewportEnd - viewportStart) * 60)) * 100

              // Only render if the etapa is at least partially visible in the viewport
              if (startPercent + widthPercent < 0 || startPercent > 100) return null

              return (
                <div
                  key={index}
                  className="absolute h-10 rounded-md border border-blue-500 bg-blue-100 dark:bg-blue-900/30 dark:border-blue-700 flex items-center justify-center overflow-hidden"
                  style={{
                    left: `${startPercent}%`,
                    width: `${widthPercent}%`,
                    minWidth: "40px",
                  }}
                >
                  <div className="text-xs font-medium px-1 truncate">{etapa.nome}</div>
                  <div className="absolute -bottom-5 left-0 text-[10px] text-gray-500">{etapa.inicio}</div>
                  <div className="absolute -bottom-5 right-0 text-[10px] text-gray-500">{etapa.fim}</div>
                </div>
              )
            })}
        </div>

        {/* Fase crítica - track 2 */}
        <div className="mb-10 relative">
          <div className="absolute -top-6 left-0 text-sm font-medium text-red-600 dark:text-red-400">Fase Crítica</div>
          {resultados.etapas
            .filter((etapa) => etapa.fase === "critica")
            .map((etapa, index) => {
              const startPercent =
                ((horarioParaMinutos(etapa.inicio) - viewportStart * 60) / ((viewportEnd - viewportStart) * 60)) * 100
              const widthPercent = (etapa.duracao / ((viewportEnd - viewportStart) * 60)) * 100

              // Only render if the etapa is at least partially visible in the viewport
              if (startPercent + widthPercent < 0 || startPercent > 100) return null

              let bgColor = "bg-red-100 dark:bg-red-900/30"
              let borderColor = "border-red-500 dark:border-red-700"
              let textColor = "text-red-800 dark:text-red-200"

              if (etapa.sobreposto) {
                bgColor = "bg-amber-100 dark:bg-amber-900/30"
                borderColor = "border-amber-500 dark:border-amber-700"
                textColor = "text-amber-800 dark:text-amber-200"
              }

              return (
                <div
                  key={index}
                  className={`absolute h-10 rounded-md border ${borderColor} ${bgColor} flex items-center justify-center overflow-hidden ${etapa.sobreposto ? "border-dashed" : ""}`}
                  style={{
                    left: `${startPercent}%`,
                    width: `${widthPercent}%`,
                    minWidth: "40px",
                  }}
                >
                  <div className={`text-xs font-medium px-1 truncate ${textColor}`}>{etapa.nome}</div>
                  <div className="absolute -bottom-5 left-0 text-[10px] text-gray-500">{etapa.inicio}</div>
                  <div className="absolute -bottom-5 right-0 text-[10px] text-gray-500">{etapa.fim}</div>
                </div>
              )
            })}
        </div>

        {/* Fase de finalização - track 3 */}
        <div className="relative">
          <div className="absolute -top-6 left-0 text-sm font-medium text-green-600 dark:text-green-400">
            Finalização
          </div>
          {resultados.etapas
            .filter((etapa) => etapa.fase === "pos")
            .map((etapa, index) => {
              const startPercent =
                ((horarioParaMinutos(etapa.inicio) - viewportStart * 60) / ((viewportEnd - viewportStart) * 60)) * 100
              const widthPercent = (etapa.duracao / ((viewportEnd - viewportStart) * 60)) * 100

              // Only render if the etapa is at least partially visible in the viewport
              if (startPercent + widthPercent < 0 || startPercent > 100) return null

              return (
                <div
                  key={index}
                  className="absolute h-10 rounded-md border border-green-500 bg-green-100 dark:bg-green-900/30 dark:border-green-700 flex items-center justify-center overflow-hidden"
                  style={{
                    left: `${startPercent}%`,
                    width: `${widthPercent}%`,
                    minWidth: "40px",
                  }}
                >
                  <div className="text-xs font-medium px-1 truncate">
                    {etapa.nome}
                    {etapa.responsavel === "medico" && " (M)"}
                  </div>
                  <div className="absolute -bottom-5 left-0 text-[10px] text-gray-500">{etapa.inicio}</div>
                  <div className="absolute -bottom-5 right-0 text-[10px] text-gray-500">{etapa.fim}</div>
                </div>
              )
            })}
        </div>
      </div>

      {/* Área crítica de 8h */}
      {resultados.tempoEntreExtracaoImplantacao > 0 && (
        <div
          className="absolute -top-6 h-[calc(100%+2rem)] pointer-events-none"
          style={{
            left: `${((horarioParaMinutos(resultados.inicioExtracao) - viewportStart * 60) / ((viewportEnd - viewportStart) * 60)) * 100}%`,
            width: `${(resultados.tempoEntreExtracaoImplantacao / ((viewportEnd - viewportStart) * 60)) * 100}%`,
            border: `1px dashed ${resultados.ultrapassouLimiteViabilidade ? "rgb(239, 68, 68)" : "rgb(34, 197, 94)"}`,
            backgroundColor: resultados.ultrapassouLimiteViabilidade
              ? "rgba(239, 68, 68, 0.05)"
              : "rgba(34, 197, 94, 0.05)",
          }}
        >
          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs whitespace-nowrap">
            <span
              className={`px-2 py-1 rounded-full ${
                resultados.ultrapassouLimiteViabilidade
                  ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                  : "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
              }`}
            >
              {formatarDuracao(resultados.tempoEntreExtracaoImplantacao)}
              {resultados.ultrapassouLimiteViabilidade ? " ⚠️" : " ✓"}
            </span>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex justify-center mt-8 gap-4 flex-wrap">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 bg-blue-100 dark:bg-blue-900/30 border border-blue-500 dark:border-blue-700 rounded-sm"></div>
          <span className="text-xs">Preparação</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 bg-red-100 dark:bg-red-900/30 border border-red-500 dark:border-red-700 rounded-sm"></div>
          <span className="text-xs">Fase Crítica</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 bg-amber-100 dark:bg-amber-900/30 border border-amber-500 dark:border-amber-700 rounded-sm border-dashed"></div>
          <span className="text-xs">Sobreposto</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 bg-green-100 dark:bg-green-900/30 border border-green-500 dark:border-green-700 rounded-sm"></div>
          <span className="text-xs">Finalização</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-xs">(M)</span>
          <span className="text-xs">Realizado pelo Médico</span>
        </div>
      </div>
    </div>
  )
}

