// Tipos para o simulador
export type Etapa = {
  id: string
  nome: string
  inicio: string
  fim: string
  duracao: number
  fase: "pre" | "critica" | "pos"
  grupo: string | null
  responsavel: string
  destaque?: boolean
  sobreposto?: boolean
}

export type Dica = {
  titulo: string
  texto: string
  impacto: "alto" | "médio" | "baixo"
}

export type Resultados = {
  etapas: Etapa[]
  tempoTotal: number
  tempoEntreExtracaoImplantacao: number
  ultrapassouLimiteViabilidade: boolean
  horarioLimiteAlta: string
  ultrapassouHorarioAlta: boolean
  dicas: Dica[]
  horarioFinalAlta: string
  inicioExtracao: string
  fimImplantacao: string
  horarioSaidaMedico: string
  horarioSaidaEquipe: string
  custoHoraExtra: number
  necessitaPernoite: boolean
  custoPernoite: number
  custoTotal: number
}

export type FormData = {
  // Configurações do local
  tipoLocal: string
  horarioAbertura: string
  horarioFechamento: string
  custoHoraExtra: number
  temCustoHoraExtra: boolean
  pernoiteObrigatorio: boolean
  horarioLimitePernoite: string
  custoPernoite: number

  // Configurações do procedimento
  horarioInicio: string
  quantidadeFoliculos: number
  velocidadeExtracao: number
  velocidadeImplantacao: number
  metodoImplantacao: string
  responsavelImplantacao: string

  // Novos campos
  tempoMarcacaoPrevia: boolean
  tempoExtracao: number
  tempoImplantacao: number

  // Configurações da equipe
  responsavelAlta: string
  responsavelLimpeza: string

  // Tempos em minutos
  tempos: {
    marcacao: number
    sedacao: number
    anestesiaDoadora: number
    anestesiaReceptora: number
    preIncisao: number
    mudancaDecubito: number
    contagem: number
    posOperatorio: number
    limpezaMateriais: number
    internacao: number
  }

  // Sequência das etapas
  sequencia: Array<{
    id: string
    nome: string
    grupo: string | null
  }>
}

