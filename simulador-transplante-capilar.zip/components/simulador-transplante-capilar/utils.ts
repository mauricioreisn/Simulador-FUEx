// Funções utilitárias

// Função para converter string de horário para minutos
export const horarioParaMinutos = (horario: string): number => {
  const [horas, minutos] = horario.split(":").map(Number)
  return horas * 60 + minutos
}

// Função para converter minutos para string de horário
export const minutosParaHorario = (minutos: number): string => {
  const horas = Math.floor(minutos / 60)
  const mins = minutos % 60
  return `${horas.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}`
}

// Função para adicionar minutos a um horário
export const adicionarMinutos = (horario: string, minutos: number): string => {
  const totalMinutos = horarioParaMinutos(horario) + minutos
  return minutosParaHorario(totalMinutos)
}

// Função para calcular a duração entre dois horários em minutos
export const calcularDuracao = (inicio: string, fim: string): number => {
  return horarioParaMinutos(fim) - horarioParaMinutos(inicio)
}

// Função para formatar a duração em formato legível
export const formatarDuracao = (minutos: number): string => {
  const horas = Math.floor(minutos / 60)
  const mins = minutos % 60
  return horas > 0 ? `${horas}h${mins > 0 ? ` ${mins}min` : ""}` : `${mins}min`
}

// Função para calcular sobrevivência estimada dos folículos
export const calcularSobrevivenciaEstimada = (tempoEmMinutos: number): number => {
  // Converter minutos para horas
  const horas = tempoEmMinutos / 60

  // Baseado no gráfico de Limmer (linha azul)
  if (horas <= 8) {
    // De 95% a 85% nas primeiras 8 horas
    return 95 - horas * (10 / 8)
  } else if (horas <= 24) {
    // De 85% a 80% entre 8 e 24 horas
    return 85 - (horas - 8) * (5 / 16)
  } else if (horas <= 48) {
    // De 80% a 55% entre 24 e 48 horas
    return 80 - (horas - 24) * (25 / 24)
  }
  // Após 48 horas
  return 55
}

